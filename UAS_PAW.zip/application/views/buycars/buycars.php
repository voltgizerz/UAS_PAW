<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title ?></h1>



</div>
<!-- /.container-fluid -->

<div class="row">
    <div class="col-lg-10 ml-3">
        <?php if (validation_errors()) : ?>
            <div class="alert alert-danger" role="alert">
                <?= validation_errors(); ?>
            </div>
        <?php endif; ?>
        <a href="" class="btn btn-primary mb-3" data-toggle="modal" data-target="#newSubMenuModal">Buy Cars</a>

        <?= $this->session->flashdata('message'); ?>
            
        <table class="table table-striped table-dark table-hover table-responsive-sm ">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Name Cars</th>
                        <th scope="col">Merk</th>
                        <th scope="col">Type</th>
                        <th scope="col">Price Deal</th>
                        <th scope="col">Contact Message</th>
                        <th scope="col">Email Buyers</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
            <tbody>
                <?php $i = 1; ?>
                <?php foreach ($dataBeliMobil as $sm) : ?>
                    <tr>
                        <th scope="row"><?= $i ?></th>
                        <td><?= $sm['name'] ?></td>
                        <td><?= $sm['merk'] ?></td>
                        <td><?= $sm['type'] ?></td>
                        <td><?= $sm['harga'] ?></td>
                        <td><?= $sm['nomorhp'] ?></td>
                        <td><?= $sm['email_pembeli'] ?></td>
                        <td>
                            <a href="<?= base_url(); ?>user/updateMobil/<?= $sm['id']; ?>" class="badge badge-primary mb-3" data-toggle="modal" data-target="#updateSubMenuModal">EDIT</a>
                            <a href="<?= base_url(); ?>user/hapusMobil/<?= $sm['id']; ?>" class="badge badge-danger mb-3">DELETE</a>
                        </td>
                    </tr>
                    <?php $i++; ?>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<!-- End of Main Content -->


<!-- Modal -->
<div class="modal fade" id="newSubMenuModal" tabindex="-1" role="dialog" aria-labelledby="#newSubMenuModal" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="newMenuModal">Add New Cars</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?= base_url('user/buycars'); ?>" method="post">
                <div class="modal-body">
                    <div class="form-group">
                        <input type="text" class="form-control" id="name" name="name" placeholder="Name Car">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="merk" name="merk" placeholder="Merk Car">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="type" name="type" placeholder="Car Type">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="harga" name="harga" placeholder="Price Deal">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="nomorhp" name="nomorhp" placeholder="Phone Number">
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add</button>
                </div>
            </form>
        </div>
    </div>
</div>